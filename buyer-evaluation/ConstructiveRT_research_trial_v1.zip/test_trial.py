import hashlib,tempfile,unittest
from pathlib import Path
from trial import source_bytes,run,LIMIT
from crcodec import codec,general
class TrialTests(unittest.TestCase):
    def test_fixtures(self):
        for f in ['shell-types-only','shell-source-histories','shell-noisy-histories','csv','random']:
            with self.subTest(f=f),tempfile.TemporaryDirectory() as d:
                data=source_bytes(None,f); r=run(data,Path(d))
                self.assertEqual(r['sourceSha256'],hashlib.sha256(data).hexdigest());self.assertFalse(r['commercialRuntimeEvaluated'])
                self.assertTrue(all(x['roundTripExact'] for x in r['results'] if 'roundTripExact' in x))
                self.assertEqual(r['results'][-1].get('applicable'),f.startswith('shell-'))
    def test_limit(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'source';p.write_bytes(b'x'*(LIMIT+1))
            with self.assertRaises(ValueError): source_bytes(p,None)
            with self.assertRaises(codec.CodecError): general.encode_general(p,Path(d)/'enc')
    def test_tamper(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d);src=d/'src';src.write_bytes(b'a,b\r\n'*20);enc=d/'enc';out=d/'out';m=general.encode_general(src,enc);enc.write_bytes(enc.read_bytes()+b'x');out.write_bytes(b'KEEP')
            with self.assertRaises(codec.CodecError):general.decode_general(enc,out,expected_source_sha256=m['source_sha256'])
            self.assertEqual(out.read_bytes(),b'KEEP')
if __name__=='__main__':unittest.main()
