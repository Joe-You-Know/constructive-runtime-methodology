"""Offline bounded CRT research codec evaluation. Python 3.11+; stdlib only."""
import argparse, gzip, hashlib, json, os, random, tempfile, time
from pathlib import Path
from crcodec import codec, general, datasets
LIMIT=1024*1024

def digest(data): return hashlib.sha256(data).hexdigest()
def timed(fn,*args,**kw):
    start=time.perf_counter(); result=fn(*args,**kw)
    return result, (time.perf_counter()-start)*1000

def put(path,data):
    with path.open('wb') as f: f.write(data); f.flush(); os.fsync(f.fileno())

def source_bytes(source,fixture):
    if source:
        with source.open('rb') as f: data=f.read(LIMIT+1)
        if len(data)>LIMIT: raise ValueError('trial source limit: 1 MiB')
        return data
    if fixture.startswith('shell-'):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'fixture'; datasets.write_fixture(p,12,fixture.removeprefix('shell-')); return p.read_bytes()
    if fixture=='csv': return (b'alpha,blue,17\r\nbeta,green,19\nalpha,blue,17\n')*4000
    return random.Random(20261127).randbytes(65536)

def run(data,out):
    if len(data)>LIMIT: raise ValueError('trial source limit: 1 MiB')
    source=out/'original.bin'; put(source,data); sha=digest(data)
    rows=[]
    def row(name,encoded,decoded,enc_ms,dec_ms,**extra):
        exact=decoded.read_bytes()==data
        if not exact: raise RuntimeError('exact recovery failed: '+name)
        rows.append(dict(codec=name,encodedBytes=encoded.stat().st_size,encodedSha256=digest(encoded.read_bytes()),decodedSha256=digest(decoded.read_bytes()),roundTripExact=True,encodeMs=enc_ms,decodeMs=dec_ms,encodedFile=encoded.name,decodedFile=decoded.name,**extra))
    def gz_encode(): put(out/'gzip.gz',gzip.compress(source.read_bytes(),compresslevel=6,mtime=0))
    def gz_decode(): put(out/'gzip.restored',gzip.decompress((out/'gzip.gz').read_bytes()))
    _,et=timed(gz_encode); _,dt=timed(gz_decode); row('gzip-6',out/'gzip.gz',out/'gzip.restored',et,dt)
    def constructive(name,enc,dec,**opts):
        p=out/(name+'.bin'); q=out/(name+'.restored')
        try: meta,et=timed(enc,source,p,**opts)
        except codec.CodecError as e:
            if name.startswith('CRTC1'): rows.append(dict(codec=name,applicable=False,reason=str(e))); return
            raise
        _,dt=timed(dec,p,q,expected_source_sha256=sha,expected_encoded_sha256=meta['encoded_sha256'],expected_source_bytes=len(data))
        row(name,p,q,et,dt,applicable=True)
    constructive('CRTCG1',general.encode_general,general.decode_general)
    constructive('CRTC1-zlib6',codec.encode,codec.decode,zlib_level=6)
    gz=rows[0]['encodedBytes']
    for r in rows:
        if 'encodedBytes' in r:r['bytesSavedVsGzip']=gz-r['encodedBytes']
    return dict(schema='crt-research-trial-v1',sourceBytes=len(data),sourceSha256=sha,trialMaxBytes=LIMIT,commercialRuntimeEvaluated=False,licenseRecommendation='NO COMMERCIAL PERFORMANCE INFERENCE',timingScope='single local run; file writes and fsync; implementation costs; not transport benchmark',results=rows)

def main():
    p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group(required=True);g.add_argument('--source',type=Path);g.add_argument('--fixture',choices=['shell-types-only','shell-source-histories','shell-noisy-histories','csv','random']);p.add_argument('--out',type=Path,help='New output directory; preserve trial artifacts (default temporary)');a=p.parse_args()
    data=source_bytes(a.source,a.fixture)
    if a.out:
        a.out.mkdir(parents=False,exist_ok=False);report=run(data,a.out);(a.out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    else:
        with tempfile.TemporaryDirectory() as d:report=run(data,Path(d))
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
