# ConstructiveRT research trial (1 MiB)

Free, offline, standard-library Python 3.11+ trial using the recovered November 2026 CRTC1 and CRTC-G1 research codec implementation. This is **not** the commercial CRT v1.5.0 Windows compiler/runtime, and trial results do not establish performance or value of that commercial package. No network, credentials or payments are required. The trial bounds source files to 1 MiB (editable source-code limit, not DRM). CRTC1 applies only to exact completed shell records; arbitrary byte files use CRTC-G1. Both are research prototypes. No general storage saving is promised.

```sh
python trial.py --fixture shell-types-only
python trial.py --fixture csv
python trial.py --source your-file.bin --out trial-output
python -m unittest -v test_trial
```

Use `py` instead of `python` on Windows if appropriate. The optional output directory must not already exist. With no output directory the utility deletes its temporary files after measurement; with an output directory it preserves the original snapshot, encoded representations, exact recovered files and JSON report. It calculates an independent source hash before encoding, verifies both encoded and source digests during constructive decode and checks restored bytes against the original. Timings include local file writes and fsync; a single trial is not a network benchmark. The report marks unsupported CRTC1 inputs explicitly, rather than substituting another codec under its name.

For economic sensitivity, run the adjacent buyer_evaluate.py with the trial-output/original.bin, the appropriate encodedFile and decodedFile in report.json, and your actual overhead and costs. **Do not interpret the paid-offer estimate as evidence of commercial CRT performance**: this research codec is distinct from the commercial compiler package. Verify the capabilities you need in the paid release separately.

The original CRTC1/CRTC-G1 implementations were recovered from ConstructiveRT_v0_3_Dataset_Economics_Hybrid_Windows_2026-11-11.zip. Only the size limits in codec.py/general.py were reduced for this trial; the fixture generator is unchanged. The wrapper and its tests are new. This distribution authorizes local evaluation of these research codecs, not redistribution of the commercial CRT package. Existing applicable license rights are preserved. No paid executable or private customer data included.
