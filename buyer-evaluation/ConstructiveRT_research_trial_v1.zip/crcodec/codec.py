"""CRTC1: exact, narrow PCL shell-type constructive record codec.

This *does not* infer full parent/history relationships from shell geometry. The
arbitrary residual after the fourth tab is kept byte-for-byte, including CR.
Every complete source file is verified against an independent SHA-256 before
atomic publication. Structural rules belong only to a deterministic v0.3
clockwise shell grammar with an explicitly marked seam and per-shell orientation.
"""
from __future__ import annotations

import hashlib
import io
import os
from pathlib import Path
import tempfile
import time
import zlib

MAGIC = b"CRTC1\x00"
VERSION = 1
MAX_SHELLS = 256  # trial limit
MAX_RECORD_BYTES = 1024 * 1024  # trial limit
MAX_TOTAL_BYTES = 1024 * 1024  # trial limit


class CodecError(ValueError):
    pass


def uvar(value: int) -> bytes:
    if value < 0 or value >= 2**64:
        raise CodecError("unsigned integer out of range")
    out = bytearray()
    while value >= 128:
        out.append((value & 127) | 128)
        value >>= 7
    out.append(value)
    return bytes(out)


def read_uvar(f) -> int:
    n = 0
    consumed=bytearray()
    for shift in range(0, 70, 7):
        chunk = f.read(1)
        if not chunk:
            raise CodecError("truncated varint")
        consumed.append(chunk[0])
        b = chunk[0]
        if shift == 63 and b > 1:
            raise CodecError("overflow varint")
        n |= (b & 127) << shift
        if b < 128:
            if uvar(n) != bytes(consumed):
                raise CodecError("noncanonical varint")
            return n
    raise CodecError("malformed varint")


def contact(k: int, j: int) -> bytes:
    """v0.3 random-access W_k token; a TYPE, not a full ancestry witness."""
    if k < 1 or not (0 <= j < 12 * k):
        raise CodecError("shell index or position out of range")
    t = j % (4 * k)
    u = t if t < 2 * k + 1 else t - (2 * k + 1)
    return b"V" if u == 0 or (u & 1) else b"E"


def orientation(seed: int, j: int) -> bytes:
    return b"UP" if ((seed ^ (j & 1)) == 0) else b"DOWN"


def record_prefix(k: int, j: int, seed: int) -> bytes:
    return str(k).encode() + b"\t" + str(j).encode() + b"\t" + contact(k, j) + b"\t" + orientation(seed, j) + b"\t"


def _source_scan(path: Path):
    h = hashlib.sha256()
    size = 0
    count = 0
    seeds = bytearray()
    with path.open('rb') as f:
        for k in range(1, MAX_SHELLS + 1):
            line = f.readline(MAX_RECORD_BYTES + 1)
            if not line:
                break
            if len(line) > MAX_RECORD_BYTES or not line.endswith(b'\n'):
                raise CodecError("line too long or not LF-terminated")
            # Position zero determines orientation seam for this shell.
            marker_up = str(k).encode() + b"\t0\t" + contact(k, 0) + b"\tUP\t"
            marker_down = str(k).encode() + b"\t0\t" + contact(k, 0) + b"\tDOWN\t"
            if line.startswith(marker_up): seed = 0
            elif line.startswith(marker_down): seed = 1
            else: raise CodecError(f"bad shell {k} start or absent seam")
            seeds.append(seed)
            for j in range(12 * k):
                if j:
                    line = f.readline(MAX_RECORD_BYTES + 1)
                if len(line) > MAX_RECORD_BYTES or not line.endswith(b'\n'):
                    raise CodecError(f"incomplete shell {k} at position {j}")
                prefix = record_prefix(k, j, seed)
                if not line.startswith(prefix):
                    raise CodecError(f"shell {k}, position {j}: expected exact type/orientation/order")
                size += len(line)
                if size > MAX_TOTAL_BYTES:
                    raise CodecError("source exceeds configured safety limit")
                h.update(line)
                count += 1
        if f.read(1):
            raise CodecError("more shells than supported")
    if not seeds:
        raise CodecError("empty input has no completed shell")
    return len(seeds), bytes(seeds), count, size, h.digest()


def _write_body(source_path: Path, out, shells: int, seeds: bytes):
    with source_path.open('rb') as f:
        for k in range(1, shells + 1):
            for j in range(12 * k):
                line = f.readline(MAX_RECORD_BYTES + 1)
                prefix = record_prefix(k, j, seeds[k-1])
                if not line.startswith(prefix) or not line.endswith(b'\n'):
                    raise CodecError("source changed between validation and encoding")
                residual = line[len(prefix):-1]
                out.write(uvar(len(residual)))
                out.write(residual)
        if f.read(1):
            raise CodecError("source grew between validation and encoding")


def _atomic_stage(dest: Path):
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.crtc-', suffix='.tmp', dir=dest.parent)
    return os.fdopen(fd, 'wb'), Path(name)


def _sync_and_replace(f, staging: Path, dest: Path):
    f.flush()
    os.fsync(f.fileno())
    f.close()
    os.replace(staging, dest)
    # parent directory durability is platform-dependent; the native CAS performs
    # its own authenticated publication, which is used in integrated receive.


def encode(source: str | Path, dest: str | Path, *, zlib_level: int | None = None) -> dict:
    """Encode only exact completed shell-order records; reject unsupported structures."""
    source, dest = Path(source), Path(dest)
    shells, seeds, count, size, source_digest = _source_scan(source)
    if zlib_level is not None and not (0 <= zlib_level <= 9):
        raise CodecError("zlib level must be 0..9")
    mode = 1 if zlib_level is not None else 0
    f, staging = _atomic_stage(dest)
    start = time.perf_counter()
    try:
        with tempfile.TemporaryFile() as body:
            _write_body(source, body, shells, seeds)
            body.seek(0)
            f.write(MAGIC + bytes([VERSION, mode]))
            f.write(uvar(shells))
            f.write(uvar(size))
            f.write(source_digest)
            f.write(bytes(1 if s else 0 for s in seeds))  # one seam orientation per shell
            if mode:
                c = zlib.compressobj(zlib_level)
                while block := body.read(1024 * 1024):
                    f.write(c.compress(block))
                f.write(c.flush())
            else:
                while block := body.read(1024 * 1024):
                    f.write(block)
        # Independent second scan: reject any intervening modification.
        verify = _source_scan(source)
        if (shells, seeds, count, size, source_digest) != verify:
            raise CodecError("source changed between encode passes")
        _sync_and_replace(f, staging, dest)
    except BaseException:
        if not f.closed: f.close()
        staging.unlink(missing_ok=True)
        raise
    return {
        "mode":"constructive-zlib" if mode else "constructive-raw",
        "shells":shells, "records":count,
        "source_bytes":size, "encoded_bytes":dest.stat().st_size,
        "source_sha256":source_digest.hex(),
        "encoded_sha256":sha256_path(dest),
        "encode_ms":round(1000*(time.perf_counter()-start),3),
    }


def _read_header(f):
    if f.read(len(MAGIC)) != MAGIC:
        raise CodecError("not a CRTC1 source representation")
    version = f.read(2)
    if len(version) != 2 or version[0] != VERSION or version[1] not in (0, 1):
        raise CodecError("unknown CRTC codec version/mode")
    shells = read_uvar(f)
    size = read_uvar(f)
    digest = f.read(32)
    if len(digest) != 32 or not (1 <= shells <= MAX_SHELLS) or size > MAX_TOTAL_BYTES:
        raise CodecError("invalid shell count, length, or digest")
    seeds = f.read(shells)
    if len(seeds) != shells or any(v not in (0,1) for v in seeds):
        raise CodecError("invalid or truncated orientation seam")
    return version[1], shells, size, digest, seeds


def sha256_path(path: Path) -> str:
    with path.open('rb') as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def _body_stream(f, mode: int, max_bytes: int):
    if mode == 0:
        return f, None
    # Bound the decoded residual stream by the declared reconstructed byte count
    # plus minimal varint overhead; never trust the stream to allocate memory.
    body = tempfile.TemporaryFile()
    dec = zlib.decompressobj()
    total = 0
    while block := f.read(1024*1024):
        if dec.eof:
            body.close()
            raise CodecError("trailing bytes after compressed stream")
        remaining_input = block
        while remaining_input:
            try:
                out = dec.decompress(remaining_input, min(max_bytes - total + 1, 4*1024*1024))
            except zlib.error as exc:
                body.close()
                raise CodecError(f"bad compressed stream: {exc}") from exc
            total += len(out)
            if total > max_bytes:
                body.close()
                raise CodecError("compressed expansion exceeds declared bound")
            body.write(out)
            if dec.unused_data:
                body.close()
                raise CodecError("trailing bytes after compressed stream")
            remaining_input = dec.unconsumed_tail
        # When the decoder reaches EOF, any later physical bytes are forbidden.
    if not dec.eof:
        body.close()
        raise CodecError("incomplete compressed stream")
    body.seek(0)
    return body, body


def decode(encoded: str | Path, dest: str | Path, *, expected_source_sha256: str,
           expected_encoded_sha256: str | None = None, expected_source_bytes: int | None = None) -> dict:
    """Fail closed: independently trusted full reconstructed SHA-256 is mandatory."""
    encoded, dest = Path(encoded), Path(dest)
    if len(expected_source_sha256) != 64 or any(c not in '0123456789abcdefABCDEF' for c in expected_source_sha256):
        raise CodecError("independent expected original SHA-256 is required")
    trusted_original = bytes.fromhex(expected_source_sha256)
    start = time.perf_counter()
    if expected_encoded_sha256 is not None:
        if len(expected_encoded_sha256) != 64 or any(c not in '0123456789abcdefABCDEF' for c in expected_encoded_sha256):
            raise CodecError("invalid expected encoded SHA-256")
        with encoded.open('rb') as verify_f:
            if hashlib.file_digest(verify_f, 'sha256').hexdigest() != expected_encoded_sha256.lower():
                raise CodecError("encoded artifact SHA-256 mismatch")
    f, stage = _atomic_stage(dest)
    try:
        with encoded.open('rb') as inp:
            mode, shells, declared_size, embedded_digest, seeds = _read_header(inp)
            if embedded_digest != trusted_original:
                raise CodecError("untrusted representation original digest differs from independently expected digest")
            if expected_source_bytes is not None and expected_source_bytes != declared_size:
                raise CodecError("original size doesn't match independently expected size")
            body, allocated = _body_stream(inp, mode, declared_size + (6 * shells * (shells+1)) * 10)
            try:
                h = hashlib.sha256()
                emitted = 0
                for k in range(1, shells+1):
                    for j in range(12*k):
                        length = read_uvar(body)
                        if length > MAX_RECORD_BYTES:
                            raise CodecError("residual record too long")
                        residual = body.read(length)
                        if len(residual) != length or b'\n' in residual:
                            raise CodecError("missing or invalid residual")
                        line = record_prefix(k, j, seeds[k-1]) + residual + b'\n'
                        emitted += len(line)
                        if emitted > declared_size:
                            raise CodecError("decoded more than expected")
                        f.write(line)
                        h.update(line)
                if body.read(1):
                    raise CodecError("trailing unconsumed residual bytes")
                if emitted != declared_size or h.digest() != trusted_original:
                    raise CodecError("full original byte length/SHA-256 verification failed")
            finally:
                if allocated: allocated.close()
        _sync_and_replace(f, stage, dest)
    except BaseException:
        if not f.closed: f.close()
        stage.unlink(missing_ok=True)
        raise
    return {"verified":True, "shells":shells, "source_bytes":declared_size,
            "source_sha256":trusted_original.hex(),
            "decode_ms":round(1000*(time.perf_counter()-start),3)}


def inspect_header(path: str|Path):
    with Path(path).open('rb') as f:
        mode, shells, size, digest, seeds = _read_header(f)
    return {"codec":"CRTC1", "compression":"zlib" if mode else "none",
            "shells":shells,"records":6*shells*(shells+1),"source_bytes":size,
            "embedded_original_sha256_NOT_TRUSTED":digest.hex()}
