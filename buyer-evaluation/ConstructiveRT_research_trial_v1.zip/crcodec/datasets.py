"""Source-preserving, deterministic structured shell fixtures for baseline audits.

Residual data here is NOT inferred from W_k: parent/source histories are independent
bytes, and any edits must survive the codec exactly or trigger hash failure.
"""
from __future__ import annotations
import hashlib, json, random
from pathlib import Path
from .codec import record_prefix


def write_fixture(path: str|Path, shells: int, variant: str, *, seed: int=7919) -> dict:
    if shells <= 0 or shells > 256:
        raise ValueError("fixture shells must be 1..256")
    if variant not in ('types-only','source-histories','noisy-histories'):
        raise ValueError('unknown source fixture variant')
    p=Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    rng=random.Random(seed)
    h=hashlib.sha256()
    size=count=0
    with p.open('wb') as f:
        for k in range(1, shells+1):
            orientation_seed=(k*7 + seed) % 2
            for j in range(12*k):
                if variant == 'types-only':
                    residual=b''
                else:
                    # Synthetic, explicit history properties: not reconstructible
                    # from shell position or geometry; retain them verbatim.
                    parent_a = rng.randrange(0, 6*k*(k-1)+1)
                    parent_b = rng.randrange(0, 6*k*(k-1)+1)
                    record={"source_id":f"S{k:04d}-P{j:06d}",
                            "parents":[parent_a,parent_b],
                            "history":f"origin={seed};path={k}/{j};join={rng.randrange(3)}"}
                    if variant=='noisy-histories':
                        record['opaque_property']=bytes(rng.getrandbits(8) for _ in range(48)).hex()
                    residual=json.dumps(record,separators=(',',':'),ensure_ascii=False).encode('utf-8')
                line=record_prefix(k,j,orientation_seed)+residual+b'\n'
                f.write(line); h.update(line); size+=len(line); count+=1
    return {"source_bytes":size,"source_sha256":h.hexdigest(),"records":count,
            "shells":shells,"variant":variant,"source_path":str(p)}
