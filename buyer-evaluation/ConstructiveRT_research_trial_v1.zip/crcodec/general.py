"""CRTCG1: byte-exact, versioned constructive token-closure representation.

Each bounded frame constructs its byte stream from a finite inventory of recurring
literal distinctions and explicitly retained residual literals. The original
sequence and comma/LF/CRLF/EOF boundaries are retained exactly. No zlib/gzip is
used. Frames whose grammar costs more than the source are stored verbatim.
This is intentionally distinct from CRTC1's PCL shell grammar.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import os
from pathlib import Path
import re
import tempfile
import time

from .codec import CodecError, uvar, read_uvar, _atomic_stage, _sync_and_replace, sha256_path

MAGIC = b'CRTCG1\x00'
VERSION = 1
FRAME_BYTES = 1024 * 1024
MAX_BYTES = 1024 * 1024  # trial limit
MAX_FRAME_WIRE_BYTES = FRAME_BYTES * 4 + 65536
MAX_DICTIONARY = 62
_TOKEN = re.compile(rb'([^,\n]*)(,|\n|$)')


def _tokenize(data: bytes):
    """Yield exact field bytes and boundary: comma=0, LF=1, CRLF=2, end=3."""
    for match in _TOKEN.finditer(data):
        if match.start() == len(data):
            break
        word, sep = match.groups()
        if sep == b',':
            boundary = 0
        elif sep == b'\n':
            if word.endswith(b'\r'):
                word, boundary = word[:-1], 2
            else:
                boundary = 1
        else:
            boundary = 3
        yield word, boundary


def _read_n(f, length: int, label: str):
    data = f.read(length)
    if len(data) != length:
        raise CodecError(f'truncated {label}')
    return data


def _word_inventory(data: bytes):
    frequencies = Counter(word for word, _ in _tokenize(data))
    # Each occurrence otherwise costs tag + varint length + literal bytes.
    # A dictionary symbol costs just one byte, plus its entry in the frame.
    ranked = []
    for word, count in frequencies.items():
        savings = count * (len(uvar(len(word))) + len(word)) - (len(uvar(len(word))) + len(word))
        if count > 1 and savings >= 8:
            ranked.append((savings, word))
    ranked.sort(key=lambda item: (-item[0], item[1]))
    return [word for _, word in ranked[:MAX_DICTIONARY]]


def _construct_frame(data: bytes):
    dictionary = _word_inventory(data)
    lookup = {word: i for i, word in enumerate(dictionary)}
    encoded = bytearray(uvar(len(dictionary)))
    for word in dictionary:
        encoded += uvar(len(word))
        encoded += word
    for word, boundary in _tokenize(data):
        symbol = lookup.get(word)
        if symbol is None:
            encoded.append((boundary << 6) | 62)
            encoded += uvar(len(word))
            encoded += word
        else:
            encoded.append((boundary << 6) | symbol)
    return bytes(encoded)


def _expand_frame(payload: bytes, expected_size: int):
    from io import BytesIO
    stream = BytesIO(payload)
    count = read_uvar(stream)
    if count > MAX_DICTIONARY:
        raise CodecError('invalid general-frame dictionary count')
    inventory = []
    for _ in range(count):
        length = read_uvar(stream)
        if length > expected_size:
            raise CodecError('dictionary entry exceeds frame')
        inventory.append(_read_n(stream, length, 'dictionary entry'))
    if len(set(inventory)) != len(inventory):
        raise CodecError('duplicate dictionary value')
    output = bytearray()
    while stream.tell() < len(payload):
        tag = _read_n(stream, 1, 'token tag')[0]
        boundary, symbol = tag >> 6, tag & 63
        if symbol < count:
            word = inventory[symbol]
        elif symbol == 62:
            length = read_uvar(stream)
            if length > expected_size - len(output):
                raise CodecError('literal exceeds frame')
            word = _read_n(stream, length, 'literal')
        else:
            raise CodecError('unknown or unavailable dictionary symbol')
        if boundary == 0:
            suffix = b','
        elif boundary == 1:
            suffix = b'\n'
        elif boundary == 2:
            suffix = b'\r\n'
        else:
            suffix = b''
            if stream.tell() != len(payload):
                raise CodecError('trailing token after end marker')
        if len(output) + len(word) + len(suffix) > expected_size:
            raise CodecError('expanded frame exceeds bound')
        output += word
        output += suffix
    if len(output) != expected_size:
        raise CodecError('frame does not reconstruct exact declared length')
    return bytes(output)


def encode_general(source: str | Path, dest: str | Path):
    """Create a lossless general-data CRTC-G1 representation, reject source races."""
    source, dest = Path(source), Path(dest)
    if source.resolve() == dest.resolve():
        raise CodecError('source and destination must differ')
    size = source.stat().st_size
    if size > MAX_BYTES:
        raise CodecError('source exceeds configured limit')
    original_digest = bytes.fromhex(sha256_path(source))
    start = time.perf_counter()
    out, staging = _atomic_stage(dest)
    frames = 0
    structured_frames = 0
    try:
        out.write(MAGIC + bytes([VERSION]))
        out.write(uvar(size))
        out.write(original_digest)
        second_digest = hashlib.sha256()
        with source.open('rb') as inp:
            while data := inp.read(FRAME_BYTES):
                second_digest.update(data)
                structured = _construct_frame(data)
                mode, payload = (1, structured) if len(structured) < len(data) else (0, data)
                out.write(bytes([mode]))
                out.write(uvar(len(data)))
                out.write(uvar(len(payload)))
                out.write(hashlib.sha256(data).digest())
                out.write(payload)
                frames += 1
                structured_frames += (mode == 1)
        if second_digest.digest() != original_digest:
            raise CodecError('source changed while encoding')
        _sync_and_replace(out, staging, dest)
    except BaseException:
        if not out.closed:
            out.close()
        staging.unlink(missing_ok=True)
        raise
    return {'codec':'CRTCG1','mode':'finite-dictionary-and-exact-residuals','source_bytes':size,
            'encoded_bytes':dest.stat().st_size,'frames':frames,'structured_frames':structured_frames,
            'source_sha256':original_digest.hex(),'encoded_sha256':sha256_path(dest),
            'encode_ms':round(1000*(time.perf_counter()-start),3)}


def decode_general(encoded: str | Path, dest: str | Path, *, expected_source_sha256: str,
                   expected_encoded_sha256: str | None = None, expected_source_bytes: int | None = None):
    """Fail-closed decoding against an independently provided source digest."""
    encoded, dest = Path(encoded), Path(dest)
    if encoded.resolve() == dest.resolve():
        raise CodecError('encoded and destination must differ')
    if len(expected_source_sha256) != 64:
        raise CodecError('independent source digest required')
    try:
        independent_digest = bytes.fromhex(expected_source_sha256)
    except ValueError as exc:
        raise CodecError('bad independent source digest') from exc
    if expected_encoded_sha256 is not None and sha256_path(encoded).lower() != expected_encoded_sha256.lower():
        raise CodecError('encoded artifact digest mismatch')
    start = time.perf_counter()
    out, staging = _atomic_stage(dest)
    frames = 0
    try:
        with encoded.open('rb') as inp:
            if _read_n(inp, len(MAGIC), 'magic') != MAGIC or _read_n(inp, 1, 'version')[0] != VERSION:
                raise CodecError('not a supported CRTC-G1 representation')
            total = read_uvar(inp)
            embedded = _read_n(inp, 32, 'source digest')
            if total > MAX_BYTES or embedded != independent_digest:
                raise CodecError('source length or independently authenticated digest disagrees')
            if expected_source_bytes is not None and total != expected_source_bytes:
                raise CodecError('unexpected independently declared source length')
            emitted = 0
            h = hashlib.sha256()
            while emitted < total:
                mode = _read_n(inp, 1, 'frame mode')[0]
                chunk_size = read_uvar(inp)
                wire_size = read_uvar(inp)
                expected_frame = _read_n(inp, 32, 'frame digest')
                if mode not in (0,1) or not 0 < chunk_size <= min(FRAME_BYTES, total-emitted) or wire_size > MAX_FRAME_WIRE_BYTES:
                    raise CodecError('invalid frame mode or frame length')
                if mode == 0 and wire_size != chunk_size:
                    raise CodecError('raw frame length mismatch')
                payload = _read_n(inp, wire_size, 'frame body')
                data = payload if mode == 0 else _expand_frame(payload, chunk_size)
                if hashlib.sha256(data).digest() != expected_frame:
                    raise CodecError('frame source digest mismatch')
                h.update(data)
                out.write(data)
                emitted += len(data)
                frames += 1
            if inp.read(1):
                raise CodecError('trailing bytes after expected frames')
            if h.digest() != independent_digest:
                raise CodecError('full source digest mismatch')
        _sync_and_replace(out, staging, dest)
    except BaseException:
        if not out.closed:
            out.close()
        staging.unlink(missing_ok=True)
        raise
    return {'codec':'CRTCG1','verified':True,'frames':frames,'source_bytes':total,
            'source_sha256':independent_digest.hex(), 'decode_ms':round(1000*(time.perf_counter()-start),3)}


def main(argv=None):
    """Usage: py -m crcodec.general encode SRC OUT | decode ARCHIVE OUT SHA256"""
    import argparse
    import json
    parser = argparse.ArgumentParser(description='Lossless CRTC-G1 general-data codec (keeps CRTC1 unchanged).')
    commands = parser.add_subparsers(dest='command', required=True)
    enc = commands.add_parser('encode', help='encode arbitrary source bytes with exact structural residuals')
    enc.add_argument('source')
    enc.add_argument('destination')
    dec = commands.add_parser('decode', help='decode only against an independent expected source SHA-256')
    dec.add_argument('encoded')
    dec.add_argument('destination')
    dec.add_argument('expected_source_sha256')
    dec.add_argument('--expected-encoded-sha256')
    dec.add_argument('--expected-source-bytes', type=int)
    a = parser.parse_args(argv)
    if a.command == 'encode':
        result = encode_general(a.source, a.destination)
    else:
        result = decode_general(a.encoded, a.destination,
                                expected_source_sha256=a.expected_source_sha256,
                                expected_encoded_sha256=a.expected_encoded_sha256,
                                expected_source_bytes=a.expected_source_bytes)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
